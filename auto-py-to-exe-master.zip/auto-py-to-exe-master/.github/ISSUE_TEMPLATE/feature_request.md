---
name: ✋ Feature request
about: Request a new feature
title: ''
labels: enhancement
assignees: brentvollebregt
---

**New Feature Description**

_A clear description of the feature being requested._

**Reason For New Feature**

_Provide context about what you're running into and why you think this feature is needed._
